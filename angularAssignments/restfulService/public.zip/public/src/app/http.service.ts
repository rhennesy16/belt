import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  constructor(private _http: HttpClient){}
    getTask(){
      return this._http.get('/task');
    }
    newTask(newTask){
      return this._http.post('/task/new', newTask);
    }
    oneTask(id: string){
      return this._http.get('/task/' + id);
    }
    removeTask(id: string){
      return this._http.delete('/task/' + id);
    }
    updateTask(id: string, task){
      return this._http.put('/task/' + id, task);
    }
  }


